
<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h1>Quiz List</h1>
    <div class="text-center">
        <table class="table">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Title</th>
                <th scope="col">From</th>
                <th scope="col">To</th>
                <th scope="col">Duration</th>
            </tr>
            </thead>
            <tbody>
            <?php
                $sl=1;
            ?>
            <?php $__currentLoopData = $quiz_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($sl++); ?></th>
                    <td><a href="/give-quiz/<?php echo e($quiz->id); ?>"><?php echo e($quiz->title); ?></a></td>
                    <td><?php echo e($quiz->from_time); ?></td>
                    <td><?php echo e($quiz->to_time); ?></td>
                    <td><?php echo e($quiz->duration); ?> minutes</td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emmanuel\REAL WORLD CODING\LARAVEL\online-quiz-system-php-laravel\resources\views/user/quiz-list.blade.php ENDPATH**/ ?>