
<?php $__env->startSection('title'); ?>
    <title>Dashboard</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <h1>Add New Quiz</h1>
    <div>
        <div>
            <div>
                <form method="post" action="<?php echo e(route('store.quiz')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <input type="text" placeholder="Quiz Title" name="title" required class="form-control">
                        <label>Valid From</label>
                        <input name="from_time" type="datetime-local">
                        <label>Valid Till</label>
                        <input name="to_time" type="datetime-local">

                    </div>
                    <div class="form-group">
                        <input class="form-control" placeholder="Duration in Minute" name="duration" type="number" required>
                    </div>
                    <div class="text-center">
                        <button class="btn btn-primary" type="submit">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emmanuel\REAL WORLD CODING\LARAVEL\online-quiz-system-php-laravel\resources\views/admin/add-quiz.blade.php ENDPATH**/ ?>